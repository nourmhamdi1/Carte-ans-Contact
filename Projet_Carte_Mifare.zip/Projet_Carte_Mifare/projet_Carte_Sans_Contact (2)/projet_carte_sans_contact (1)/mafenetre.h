#ifndef MAFENETRE_H
#define MAFENETRE_H

#include <QWidget>
#include <cstdint>

QT_BEGIN_NAMESPACE
namespace Ui { class MaFenetre; }
QT_END_NAMESPACE

class MaFenetre : public QWidget
{
    Q_OBJECT

public:
    explicit MaFenetre(QWidget *parent = nullptr);
    ~MaFenetre();

private slots:

     void on_Connect_clicked();
    void on_Selectionner_clicked();
     void on_Mise_clicked();
    void on_Payer_clicked();
    void on_Charger_clicked();
     void on_Disconnect_clicked();
    void on_Quitter_clicked();

private:
    Ui::MaFenetre *ui;


    bool m_lecteurOuvert;
    bool m_cartePresente;
    uint32_t m_soldeCourant;   // nbr unites

    // méthodes
    void afficherMessage(const QString &msg);

     bool ecrireIdentite(const QString &prenom, const QString &nom);
      bool lireIdentite(QString &prenom, QString &nom);

     bool lireSolde(uint32_t &solde);
     bool ecrireSolde(uint32_t solde);
     void rafraichirAffichageSolde();

    void initialiserChampsGUI();
};

#endif
