#include "mafenetre.h"
#include "ui_mafenetre.h"


#include "MfErrNo.h"
#include "Sw_Device.h"
#include "Sw_ISO14443A-3.h"
#include "Sw_Mf_Classic.h"
#include "Tools.h"
#include "TypeDefs.h"

#include <QDebug>
#include <QMessageBox>
#include <cstring>

// def des clés
#ifndef MIFARE_KEY_A
#define MIFARE_KEY_A 0
#endif

#ifndef MIFARE_KEY_B
#define MIFARE_KEY_B 1
#endif

// def des leds
#ifndef LED_ON
#define LED_ON  1
#endif

#ifndef LED_OFF
#define LED_OFF 0
#endif


ReaderName MonLecteur;


MaFenetre::MaFenetre(QWidget *parent)
    : QWidget(parent) , ui(new Ui::MaFenetre), m_lecteurOuvert(false) , m_cartePresente(false) , m_soldeCourant(0)
{
    ui->setupUi(this);
    initialiserChampsGUI();
}

MaFenetre::~MaFenetre()
{
    delete ui;
}


void MaFenetre::initialiserChampsGUI()
{

    ui->Nom->clear();
    ui->Prenom->clear();


    ui->Affichage_Unites->setReadOnly(true);
     ui->Affichage_Unites->setText("0");

    ui->Spin_Dec->setMinimum(0);
     ui->Spin_Dec->setMaximum(1000);
    ui->Spin_Dec->setValue(0);

     ui->Spin_Inc->setMinimum(0);
    ui->Spin_Inc->setMaximum(1000);
    ui->Spin_Inc->setValue(0);


    ui->Affichage->clear();
}

void MaFenetre::afficherMessage(const QString &msg)
{
    ui->Affichage->append(msg);
    qDebug() << msg;
}



void MaFenetre::on_Connect_clicked()
{
    int16_t status = MI_OK;

    // cnfig du lecteur
    MonLecteur.Type   = ReaderCDC;
    MonLecteur.device = 0;


    status = OpenCOM(&MonLecteur);
    if (status != MI_OK) {
        afficherMessage("erreur OpenCOM (Connect)");
        return;
    }
    m_lecteurOuvert = true;
    afficherMessage("lecteur connecté.");

    status = Version(&MonLecteur);
    if (status == MI_OK) {
        ui->Affichage->append(QString("version lecteur : %1").arg(QString::fromLatin1(MonLecteur.version)));
    } else {
        afficherMessage("rrreur lors de la lecture de la version");
    }

    status = RF_Power_Control(&MonLecteur, TRUE, 0);
    if (status != MI_OK) {
        afficherMessage("erreur RF_Power_Control(TRUE)");
    } else {
        afficherMessage("champ RF activé");
    }


    LEDBuzzer(&MonLecteur, LED_ON);
}



void MaFenetre::on_Selectionner_clicked()
{
    if (!m_lecteurOuvert) {
        QMessageBox::warning(this, "erreur", "Le lecteur n est pas connecté.");
        return;
    }
    m_cartePresente = true;

    //  identité
    QString prenom, nom;
    if (lireIdentite(prenom, nom)) {
        ui->Prenom->setText(prenom);
        ui->Nom->setText(nom);
        afficherMessage("carte selectionnée : ok ");
    } else {
        afficherMessage("carte sélectionnée :inconnue ");
    }

    //  solde
    uint32_t solde = 0;
    if (lireSolde(solde)) {
        m_soldeCourant = solde;
        rafraichirAffichageSolde();
        afficherMessage(QString("solde sur la carte :")
                        .arg(m_soldeCourant));
    } else {
        afficherMessage("impo de lire le solde ");
    }

    LEDBuzzer(&MonLecteur, LED_ON);
}


void MaFenetre::on_Disconnect_clicked()
{
    int16_t status = MI_OK;

    if (m_lecteurOuvert) {
        status = RF_Power_Control(&MonLecteur, FALSE, 0);
        qDebug() << "RF Power OFF =" << status;

        status = LEDBuzzer(&MonLecteur, LED_OFF);
        qDebug() << "LEDBuzzer =" << status;

        status = CloseCOM(&MonLecteur);
        qDebug() << "CloseCOM =" << status;

        m_lecteurOuvert = false;
        m_cartePresente = false;
    }

    ui->Affichage->append("lecteur déconnecté.");
}

void MaFenetre::on_Quitter_clicked()
{

    on_Disconnect_clicked();
    qApp->quit();
}


bool MaFenetre::ecrireIdentite(const QString &prenom, const QString &nom)
{
    if (!m_lecteurOuvert || !m_cartePresente)
        return false;

    int16_t status = MI_OK;

    char dataApp[16] = {0};
    std::strncpy(dataApp, "Identite", 16);

    status = Mf_Classic_Write_Block(&MonLecteur,
                             true,       // authen
                                 8,       // bloc
                                  (uint8_t*)dataApp,
                                 true,       // Key B
                                    2);         // index 2
    if (status != MI_OK) {
        afficherMessage("Erreur écriture bloc 8 (Identite).");
        return false;
    }

    //  prenom
    QByteArray prenomUtf8 = prenom.toUtf8();
    char dataPrenom[16] = {0};
    std::strncpy(dataPrenom, prenomUtf8.constData(), 16);

    status = Mf_Classic_Write_Block(&MonLecteur, true, 9,(uint8_t*)dataPrenom,true, 2);
    if (status != MI_OK) {
        afficherMessage("Erreur écriture bloc 9 (Prenom).");
        return false;
    }

    // nom
    QByteArray nomUtf8 = nom.toUtf8();
    char dataNom[16] = {0};
    std::strncpy(dataNom, nomUtf8.constData(), 16);

    status = Mf_Classic_Write_Block(&MonLecteur,true, 10,(uint8_t*)dataNom, true, 2);
    if (status != MI_OK) {
        afficherMessage("Erreur écriture bloc 10 (Nom).");
        return false;
    }

    return true;
}


bool MaFenetre::lireIdentite(QString &prenom, QString &nom)
{
    if (!m_lecteurOuvert || !m_cartePresente)
        return false;

    int16_t status = MI_OK;
    unsigned char readPrenom[16] = {0};
    unsigned char readNom[16]    = {0};

    status = Mf_Classic_Read_Block(&MonLecteur, true, 9,readPrenom,false, 2);
    if (status != MI_OK) {
        return false;
    }

    status = Mf_Classic_Read_Block(&MonLecteur, true, 10,readNom,false, 2);
    if (status != MI_OK) {
        return false;
    }

    prenom = QString::fromUtf8((char*)readPrenom, 16).trimmed();
    nom    = QString::fromUtf8((char*)readNom,    16).trimmed();
    return true;
}

// le bouton mise a jour
void MaFenetre::on_Mise_clicked()
{
    if (!m_lecteurOuvert) {
        QMessageBox::warning(this, "erreur", "le lecteur n est pas connecté");
        return;
    }

    if (!m_cartePresente) {
        QMessageBox::warning(this, "erreur", "aucune carte sélectionnée");
        return;
    }

    QString prenom = ui->Prenom->text();
    QString nom    = ui->Nom->text();

    if (prenom.isEmpty() || nom.isEmpty()) {
        QMessageBox::information(this, "veuillez saisir le nom et le prenom.");
        return;
    }

    if (!ecrireIdentite(prenom, nom)) {
        QMessageBox::critical(this, "erreur");
        return;
    }

    QString prenomLU, nomLU;
    if (lireIdentite(prenomLU, nomLU)) {
        ui->Affichage->append(
            QString("identité mise à jour : %1 %2")
                .arg(prenomLU, nomLU));
    } else {
        ui->Affichage->append("mise à jour effectuée");
    }

    LEDBuzzer(&MonLecteur, LED_ON);
}



// lecture du solde courant
bool MaFenetre::lireSolde(uint32_t &solde)
{
    if (!m_lecteurOuvert || !m_cartePresente)
        return false;

    int16_t status = MI_OK;
    uint8_t buf13[16] = {0};
    uint8_t buf14[16] = {0};

    // Bloc 13 : backup
    status = Mf_Classic_Read_Block(&MonLecteur,true, 13, buf13,false, 3);  // cle A index 3 (lecture/descrémentation)
    if (status != MI_OK) {
        return false;
    }

    //  compteur princpl
    status = Mf_Classic_Read_Block(&MonLecteur,true, 14, buf14,false, 3);  // cle A index 3
    if (status != MI_OK) {
        return false;
    }

    uint32_t val13 = 0;
    uint32_t val14 = 0;
    std::memcpy(&val13, buf13, sizeof(uint32_t));
    std::memcpy(&val14, buf14, sizeof(uint32_t));

    if (val13 != val14) {

        solde = std::min(val13, val14);
        afficherMessage(QString("Alerte backup : valeurs différentes (%1 / %2). " "Utilisation de la plus petite.").arg(val13).arg(val14));
    } else {
        solde = val13;
    }

    return true;
}

// ecriture du solde dans les blocs 13  14 et  bloc 12
bool MaFenetre::ecrireSolde(uint32_t solde)
{
    if (!m_lecteurOuvert || !m_cartePresente)
        return false;

    int16_t status = MI_OK;

    // bloc 12 : nom d’app "Porte Monnaie"
    char dataApp[16] = {0};
    std::strncpy(dataApp, "Porte Monnaie", 16);

    status = Mf_Classic_Write_Block(&MonLecteur,true, 12,(uint8_t*)dataApp,true, 3);   // Key B index 3 (ecriture)
    if (status != MI_OK) {
        afficherMessage("erreur écriture bloc 12");
        return false;
    }

    // prepare le buffer compteur
    uint8_t buf[16] = {0};
    std::memcpy(buf, &solde, sizeof(uint32_t));

    // bloc 13 : backup
    status = Mf_Classic_Write_Block(&MonLecteur,true, 13,buf,true, 3);   // Key B index 3
    if (status != MI_OK) {
        afficherMessage("erreur écriture bloc 13 (backup compteur).");
        return false;
    }

    // bloc 14 : compteur
    status = Mf_Classic_Write_Block(&MonLecteur,true, 14,buf,true, 3);   // Key B index 3
    if (status != MI_OK) {
        afficherMessage("erreur écriture bloc 14 (compteur).");
        return false;
    }

    return true;
}

void MaFenetre::rafraichirAffichageSolde()
{
    ui->Affichage_Unites->setText(QString::number(m_soldeCourant));
}

// payer : decrementation
void MaFenetre::on_Payer_clicked()
{
    if (!m_lecteurOuvert) {
        QMessageBox::warning(this, "erreur", "le lecteur n est pas connecté");
        return;
    }

    if (!m_cartePresente) {
        QMessageBox::warning(this, "erreur", "aucune carte sélectionnée");
        return;
    }

    int nb = ui->Spin_Dec->value();
    if (nb <= 0) {
        QMessageBox::information(this, "info","veuillez choisir un nombre d'unités à décrémenter > 0");
        return;
    }

    uint32_t soldeLu = 0;
    if (!lireSolde(soldeLu)) {
        QMessageBox::critical(this, "erreur", "impossible de lire le solde");
        return;
    }

    if (soldeLu < (uint32_t)nb) {
        QMessageBox::warning(this, "solde insuffisant","le solde ne permet pas ce paiement");
        return;
    }

    uint32_t nouveauSolde = soldeLu - (uint32_t)nb;


    if (!ecrireSolde(nouveauSolde)) {
        QMessageBox::critical(this, "erreur", "echec mise à jour porte-monnaie");
        return;
    }

    m_soldeCourant = nouveauSolde;
    rafraichirAffichageSolde();
    ui->Spin_Dec->setValue(0);
    afficherMessage(QString("paiement de %1 unité(s). nouveau solde : %2") .arg(nb).arg(m_soldeCourant));

    LEDBuzzer(&MonLecteur, LED_ON);
}

// charger : incrémentation
void MaFenetre::on_Charger_clicked()
{
    if (!m_lecteurOuvert) {
        QMessageBox::warning(this, "erreur", "le lecteur n est pas connecté");
        return;
    }

    if (!m_cartePresente) {
        QMessageBox::warning(this, "erreur", "aucune carte sélectionnée");
        return;
    }

    int nb = ui->Spin_Inc->value();
    if (nb <= 0) {
        QMessageBox::information(this, "info", "veuillez choisir un nbr d'unités à incrémenter > 0");
        return;
    }

    uint32_t soldeLu = 0;
    if (!lireSolde(soldeLu)) {
        // si lecture impossible (carte neuve), on part de 0
            soldeLu = 0;
    }

    uint32_t nouveauSolde = soldeLu + (uint32_t)nb;


    if (!ecrireSolde(nouveauSolde)) {
        QMessageBox::critical(this, "erreur", "echec mise à jour porte-monnaie");
        return;
    }

    m_soldeCourant = nouveauSolde;
    rafraichirAffichageSolde();
    ui->Spin_Inc->setValue(0);
    afficherMessage(QString("chargement de %1 unité(s). nouveau solde : %2").arg(nb).arg(m_soldeCourant));

    LEDBuzzer(&MonLecteur, LED_ON);
}
